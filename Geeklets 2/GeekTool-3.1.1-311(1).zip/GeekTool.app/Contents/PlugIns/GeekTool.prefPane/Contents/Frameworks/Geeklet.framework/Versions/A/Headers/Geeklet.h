//
//  Geeklet.h
//  GeekTool 3
//
//  Created by Yann Bizeul on 19/09/04.
//  Copyright 2004 Tynsoe.org. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "GeekletWindow.h"
#import "../../GeekTool Helper/GTPluginsController.h"
#import "GeekletUserDefaults.h"

#define kGeekletWindowLevel (kCGDesktopWindowLevel+15)
#define kSelectedGeekletWindowLevel (kCGDesktopWindowLevel+20)
#define kKeepOnTopGeekletWindowLevel (NSStatusWindowLevel)
@interface Geeklet : NSObject <NSWindowDelegate> {
	IBOutlet GeekletWindow *window;
	IBOutlet NSView *propertiesView;
	IBOutlet NSView *settingsView;
	BOOL selected;
	BOOL movable;
	BOOL visible;
	NSWindowController *windowController;
	NSString *UUID;
}
@property int visible;
@property BOOL selected;
@property BOOL movable;
@property (readonly) NSView *settingsView;
@property (readonly) NSString *geekletIdentifier;
@property (readonly) NSString *UUID;
@property (copy) NSString *name;

@property BOOL keepOnTop;
//@property BOOL ignoreExpose;
@property BOOL hasShadow;

@property (readonly) GeekletWindow *window;

@property (readonly) NSUndoManager *undoManager;
+ (NSString*)makeUUID;

+ (NSString*)geekletIdentifier;
+ (NSString*)name;
+ (NSImage*)icon;
+ (NSRect)userRectToQuartzRect:(NSRect)aRect;
+ (NSRect)quartzRectToUserRect:(NSRect)aRect;
+ (NSImage*)defaultImage;

+ (NSArray*)pluginUUIDs:(NSString*)anIdentifier;
+ (NSImage*)inspectorIcon;
- (int)userVisible;
- (NSImage*)inspectorIcon;
- (BOOL)isOpen;
- (void)open;
- (void)openGeeklet;
- (void)close;
- (NSArray*)groups;
- (GeekletUserDefaults*)userDefaults;
- (void)refresh;
- (NSString*)createSettingsFile;
- (BOOL)shouldAcceptImportedGeeklet;
- (void)setFrameForCurrentScreenConfiguration;
- (BOOL)settingsViewShouldUnload;
@end

@interface Geeklet (Informal)
- (void)geekletDidLoad;
- (void)settingsViewWillLoad;
- (void)settingsViewWillUnload;
- (void)settingsViewDidLoad;
@end
