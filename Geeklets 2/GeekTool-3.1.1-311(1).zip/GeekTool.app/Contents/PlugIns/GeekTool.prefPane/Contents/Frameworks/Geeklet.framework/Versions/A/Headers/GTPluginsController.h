/* GeekletsController */

#import <Cocoa/Cocoa.h>
@class Geeklet;
@interface GTPluginsController : NSObject
{
	NSArray *_plugins;
	NSMutableDictionary *_pluginsPaths;
}
+ (GTPluginsController*)sharedController;
- (NSArray *)allPlugins;
- (NSString *)pathForPluginWithIdentifier:(NSString*)anIdentifier;
@end
