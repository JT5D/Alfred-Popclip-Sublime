# BibleGateway

This extension identifies Bible references in selected text and uses Biblegateway.com to look them up.

Original extension by [1of144000](http://1of144000.org), with further modifications by Nick Moore.