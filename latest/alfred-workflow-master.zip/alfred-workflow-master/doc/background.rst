workflow.background
-----------------

.. automodule:: workflow.background
    :members: run_in_background, is_running
    :undoc-members:
    :show-inheritance:

